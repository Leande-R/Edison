package org.example;

public enum ChargingStatus {
    IN_OPERATION_FREE,
    OCCUPIED,
    OUT_OF_ORDER
}