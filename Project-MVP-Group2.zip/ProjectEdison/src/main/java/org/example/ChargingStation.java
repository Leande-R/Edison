package org.example;

public class ChargingStation {
    private String location;
    private String name;
    private double priceAC;
    private double priceDC;



    public ChargingStation(String location, String name, double priceAC, double priceDC) {
        this.location = location;
        this.name = name;
        this.priceAC = priceAC;
        this.priceDC = priceDC;
    }




    //GETTER AND SETTER


    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public double getPriceAC() {
        return priceAC;
    }

    public void setPriceAC(double priceAC) {
        this.priceAC = priceAC;
    }

    public double getPriceDC() {
        return priceDC;
    }

    public void setPriceDC(double priceDC) {
        this.priceDC = priceDC;
    }

}
