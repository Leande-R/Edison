package org.example;

public enum ChargingMethod {
    AC,
    DC
}